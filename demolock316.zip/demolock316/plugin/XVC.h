//
//  XRKSettingsViewController.h
//  hookwechat
//
//  Created by TsuiYuenHong on 2017/3/4.
//
//

#import <UIKit/UIKit.h>

@interface XRKSettingsViewController : UIViewController

@end

@interface SHFontCycleLabel : UIView


@property (nonatomic, strong) UILabel *myLabel;

@property (nonatomic, copy) NSString *labelText;


@end

